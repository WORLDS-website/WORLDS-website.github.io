Credits:

Bernard (Lebert): Christmas tech demo
https://worlds-website.github.io/

Kat Purpy: Debugging the game engine
https://katpurpy.github.io/


Special thanks:

-Admer456
-Totterynine
-Bacontsu

Thank you everyone who supported me so far, I really appreciate it.

And merry christmas and happy holidays, I hope you have a great day anybody who is reading this.
I hope I can achieve more milestones to the point of completing this game engine, so far it has been fun
making this game engine.

If you wish to support me, go to these links:

https://www.patreon.com/lebert130
https://ko-fi.com/lebert130
https://en.liberapay.com/Lebert130/